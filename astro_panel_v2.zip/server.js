// server.js - simulate server metrics and console interactions
document.addEventListener('DOMContentLoaded', ()=>{
  const cpuVal = document.getElementById('cpuVal')
  const ramVal = document.getElementById('ramVal')
  const cpuBar = document.getElementById('cpuBar')
  const ramBar = document.getElementById('ramBar')
  const cpuBar2 = document.getElementById('cpuBar2')
  const ramBar2 = document.getElementById('ramBar2')
  const consoleWrap = document.getElementById('consoleWrap')
  const statusLabel = document.getElementById('statusLabel')
  const uptimeEl = document.getElementById('uptime')
  let online = true, seconds = 0

  function updateMetrics(){
    const cpu = Math.floor(10 + Math.random()*60)
    const ramPerc = Math.floor(20 + Math.random()*60)
    cpuVal.textContent = cpu + '%'
    ramVal.textContent = Math.floor(512 + ramPerc*4) + 'MB'
    cpuBar.style.width = cpu + '%'
    ramBar.style.width = ramPerc + '%'
    cpuBar2.style.width = cpu + '%'
    ramBar2.style.width = ramPerc + '%'
  }

  function tickUptime(){
    if(online) seconds++
    const h = String(Math.floor(seconds/3600)).padStart(2,'0')
    const m = String(Math.floor(seconds%3600/60)).padStart(2,'0')
    const s = String(seconds%60).padStart(2,'0')
    uptimeEl.textContent = h+':'+m+':'+s
  }

  setInterval(updateMetrics, 3000)
  setInterval(tickUptime, 1000)

  // Console auto logs
  let logCount = 0
  setInterval(()=>{
    logCount++
    const d = new Date().toTimeString().split(' ')[0].slice(0,5)
    const line = document.createElement('div')
    line.className = 'console-line'
    line.textContent = `[${d}] Auto: event #${logCount}`
    consoleWrap.appendChild(line)
    consoleWrap.scrollTop = consoleWrap.scrollHeight
  }, 5000)

  // Controls
  document.getElementById('startBtn').addEventListener('click', ()=>{
    online = true; statusLabel.textContent='Online'
    const line = document.createElement('div'); line.className='console-line'; line.textContent='[Server] Start requested.'; consoleWrap.appendChild(line); consoleWrap.scrollTop = consoleWrap.scrollHeight
  })
  document.getElementById('stopBtn').addEventListener('click', ()=>{
    online = false; statusLabel.textContent='Offline'
    const line = document.createElement('div'); line.className='console-line'; line.textContent='[Server] Stop requested.'; consoleWrap.appendChild(line); consoleWrap.scrollTop = consoleWrap.scrollHeight
  })
  document.getElementById('restartBtn').addEventListener('click', ()=>{
    online = true; statusLabel.textContent='Online'
    const line = document.createElement('div'); line.className='console-line'; line.textContent='[Server] Restarted.'; consoleWrap.appendChild(line); consoleWrap.scrollTop = consoleWrap.scrollHeight
  })

  // Send command
  document.getElementById('sendCmd').addEventListener('click', ()=>{
    const input = document.getElementById('cmdInput')
    if(!input.value) return
    const line = document.createElement('div'); line.className='console-line'; line.textContent='[CONSOLE] > '+input.value; consoleWrap.appendChild(line); consoleWrap.scrollTop = consoleWrap.scrollHeight
    input.value=''
  })
})