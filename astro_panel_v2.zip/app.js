// Simple interactivity for Astro Panel
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.sidebar li').forEach(li => {
    li.addEventListener('click', () => {
      document.querySelectorAll('.sidebar li').forEach(x=>x.classList.remove('active'))
      li.classList.add('active')
    })
  })

  // Console sample: add a new line every 5 seconds
  const consoleEl = document.querySelector('.console')
  let count = 0
  setInterval(()=>{
    count++
    const d = new Date().toTimeString().split(' ')[0].slice(0,5)
    const line = document.createElement('div')
    line.className = 'console-line'
    line.textContent = `[${d}] Auto log: event #${count}`
    consoleEl.appendChild(line)
    consoleEl.scrollTop = consoleEl.scrollHeight
  }, 5000)
})